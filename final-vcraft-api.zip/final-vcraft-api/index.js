const express = require("express");
const fs = require("fs");
const now = new Date().getHours();
const nowMin = new Date().getMinutes();
const app = express();
const port = 3000;
const axios = require("axios");
const PARAMSECRETE = "48bda032780dea"
const SECRETE = "VerusVeruVerVeVVerusCraftandverusbothwillgotothemoonsoonimeanidontknowwhenbutitwilldefinatelygotothemoon"
app.use(express.json());

let timerApproval = 1;

app.post("/api/data/:_id", (req, res) => {
  const {_id} = req.params
  const data = req.body;
  if (_id !== PARAMSECRETE){
    res.json({data:"Access denied"})
  }
  // Check if data is an array of objects
  if (!Array.isArray(data)) {
    res
      .status(400)
      .send("Bad Request: Request body must be an array of objects");
    return;
  }

  // Check if all objects in array have a name property
  if (data.some((obj) => !obj.hasOwnProperty("addr"))) {
    res.status(400).send("Bad Request: wrong request data");
    return;
  }

  fs.access("db.json", fs.constants.F_OK, (err) => {
    if (err) {
      // File does not exist, create it
      fs.writeFile("db.json", '{"users":[]}', (err) => {
        if (err) {
          console.error("Error creating file:", err);
        } else {
          console.log(`File db.json created successfully`);
        }
      });
    } else {
      console.log(`File db.json already exists`);
    }
  });



  // Read existing data from db.json file
  fs.readFile("db.json", "utf8", (err, jsonString) => {
    if (err) {
      console.log("Error reading file:", err);
      res.status(500).send("Internal Server Error");
      return;
    }

    let existingData = JSON.parse(jsonString);
    let updatedb = existingData;
    // console.log(existingData);

    // if the coming address and existing db address matches we update total balance based on coins earned

    if (now < 23) {
      timerApproval = true;
      if (updatedb.users.length == 0) {
        data.map((d) => {
          updatedb.users.push({
            playtime: d.time,
            currentbalance: parseFloat(d.verus),
            totalbalance: 0,
            address: d.addr,
          });
          console.log(updatedb);
        });
      } else if (updatedb.users.length > 0) {
        const uadata = updatedb.users.map((d) => d.address);
        data.map((d) => {
          if (uadata.includes(d.addr) & (parseFloat(d.verus) !== 0)) {
            updatedb.users.map((udata, index) => {
              if (udata.address == d.addr) {
                let t = udata.currentbalance + udata.totalbalance;
                udata.totalbalance = t;
                udata.currentbalance = parseFloat(d.verus);
                console.log("matched");
              }
            });
          } else if (!uadata.includes(d.addr) & (parseFloat(d.verus) !== 0)) {
            updatedb.users.push({
              playtime: d.time,
              currentbalance: parseFloat(d.verus),
              totalbalance: 0,
              address: d.addr,
            });
          }
        });
      }
      // Save data to db.json file
      fs.writeFile("db.json", JSON.stringify(updatedb), "utf8", (err) => {
        if (err) {
          console.log("Error writing file:", err);
          res.status(500).send("Internal Server Error");
          return;
        } else {
          res.status(200).send("Data saved successfully");
        }
      });
    } else {
      res.status(200).send("Server is Processing payments");
    }
  });
});

///timer that calculates the current time and calls the payment process api

let finaldata;

function callApiForDays(tobepaid) {
  tobepaid.map((d, index) => {
    setTimeout(() => {
      axios
        .post("http://pool.veruscraft.in:8001/pay_verus_craft/", {"amount": d.totalbalance, "address": d.address, token:SECRETE })
        .then((res) => {
          console.log(new Date().getMinutes());
          console.log(res.data);
        })
        .catch((error) => {
          console.log("error communicating with api");
        });
    }, index * 6000);
  });

  //clearing existing transaction
  fs.writeFile("db.json", '{"users":[]}', "utf8", (err) => {
    if (err) {
      console.log("Error writing file:", err);
      return;
    } else {
      console.log("Data cleared successfully");
    }
  });
}

const payment_processor = () => {
  timerApproval = false
  console.log("I am called");
  fs.readFile("db.json", "utf8", (err, jsonString) => {
    if (err) {
      console.log("Error reading file:", err);
      res.status(500).send("Internal Server Error");
      return;
    }
    finaldata = JSON.parse(jsonString);
    finaldata.users.map((fdata) => {
      let fadd = fdata.currentbalance + fdata.totalbalance;
      fdata.totalbalance = fadd;
      fdata.currentbalance = 0;
    });

    callApiForDays(finaldata.users);
  });
};

setInterval(() => {
  if (now == 23 & nowMin == 05 ) {
    payment_processor();
}
console.log("Checking current time....")
},15000);


app.listen(port, () => {
  console.log(`Server listening at http://localhost:${port}`);
});
